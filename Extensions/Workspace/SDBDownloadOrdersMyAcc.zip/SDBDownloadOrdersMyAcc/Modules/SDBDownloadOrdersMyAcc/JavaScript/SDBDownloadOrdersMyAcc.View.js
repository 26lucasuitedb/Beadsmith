// @module SuiteDB.SDBDownloadOrdersMyAcc.SDBDownloadOrdersMyAcc
define('SuiteDB.SDBDownloadOrdersMyAcc.SDBDownloadOrdersMyAcc.View'
	, [
		'suitedb_sdbdownloadordersmyacc_sdbdownloadordersmyacc.tpl'
		, 'Backbone'

		, 'OrderHistory.Details.View'

		, 'OrderHistory.List.View'

		, 'CSVDownloadOrder.Helper'
	]
	, function (
		suitedb_sdbdownloadordersmyacc_sdbdownloadordersmyacc_tpl


		, Backbone

		, OrderDetailsView

		, OrderHistoryListView

		, CSVDownloadOrderHelper

	) {
		'use strict';

		// @class SuiteDB.SDBDownloadOrdersMyAcc.SDBDownloadOrdersMyAcc.View @extends Backbone.View
		return Backbone.View.extend({

			template: suitedb_sdbdownloadordersmyacc_sdbdownloadordersmyacc_tpl

			, initialize: function (options) {


				var self = this;

				this.application = this.options.container;
				this.parentView = this.application.getLayout().getCurrentView();
				console.log("Hello from the SDBDownloadOrdersMyAcc View " + window.location.href);
			}

			, events: {
				'click [data-action="downloadordercsv"]': 'downloadOrderCSV',
			}

			, bindings: {
			}

			, childViews: {

			}

			, render: function () {
				{
					// "How do I conditionally do something based on what the current view is?"
					if (!this.options.checkParent) this._render();
					if (this.parentView.parentView.parentView instanceof OrderHistoryListView || this.parentView instanceof OrderDetailsView) {
						this._render(); // this is the 'real' method
					}
					// by doing nothing if it is false, it won't render on pages that aren't the order history list view
				}
			}

			, downloadOrderCSV: function downloadOrderCSV() {
				if (this.options.checkParent) {
					var orderHistoryModels = this.parentView.parentView.parentView.collection.models // get order data straight from the view's collection's models
					var orderHistoryColumns = this.application.getConfig('transactionListColumns.enableOrderHistory') ? this.application.getConfig().transactionListColumns.orderHistory : Helper.getDefaultColumns() // Does this site use custom order history columns? If so, get them, otherwise provide some defaults
					var orderHistoryMap = CSVDownloadOrderHelper.mapList(orderHistoryModels, orderHistoryColumns) // map the data into JSON format that the parsing system can understand
					// var CSVServiceURL = Helper.getServiceUrl() + '?orderHistory=' + JSON.stringify(orderHistoryMap); // generate the URL for the service, to which we will attach a stringified version of the processed of the data
				}
				debugger;
				// So, here's the thing. If you have a service you need to call in your extension then you can use jQuery/XHR to get it. BUT if you're going to use this GET to get model/collection data, then you should use standard Backbone model/collection stuff. This is only if you need to make a call to NetSuite for other uses.
				// jQuery.get(CSVServiceURL).then(function (CSVfile) {
				// 	// After calling the service and getting our response, we need to do something with the file. But unfortunately the download / 'save as' mechanism won't automatically trigger :(
				// 	// The web standards folk *were* going to make downloading files super easy with an API but they canceled that idea, sadly.
				// 	// Some people have tried to resurrect it by creating a library, etc, but that's a bit overkill, I think: https://developers.google.com/web/updates/2011/08/Saving-generated-files-on-the-client-side
				// 	// The reason I think that is because there are a couple of easy ways to do it that are 'hacky' but reliable (and, to be honest, the library just wraps those hacks up and makes them look pretty)
				// 	// Anyway, you basically create a fake link that reads the data and converts it into a file.
				// 	// We then trigger a click() event and download it.
				// 	// Wait. Does that mean we don't even need to bother generating the file on NetSuite? :thinking_face:
				// 	var element = document.createElement('a');
				// 	element.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(CSVfile));
				// 	element.setAttribute('download', 'OrderHistory.csv');
				// 	element.style.display = 'none';

				// 	document.body.appendChild(element);
				// 	element.click();
				// 	document.body.removeChild(element);
				// });
			}

			//@method getContext @return SuiteDB.SDBDownloadOrdersMyAcc.SDBDownloadOrdersMyAcc.View.Context
			, getContext: function getContext() {
				//@class SuiteDB.SDBDownloadOrdersMyAcc.SDBDownloadOrdersMyAcc.View.Context
				this.message = this.message || 'Hello World!!'
				return {
					message: this.message
				};
			}
		});
	});
